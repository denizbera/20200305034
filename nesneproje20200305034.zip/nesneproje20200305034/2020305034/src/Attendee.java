interface Attendee {

    void setMarkAttendee();

}