public interface SingleLineLambdaInterface {
    void apply();
}